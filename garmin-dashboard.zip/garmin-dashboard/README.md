# Garmin-Dashboard (automatisch, passwortgeschützt, fürs Handy)

Ein Skript holt alle 3 Stunden deine Daten über Garmins offizielle **Personal API**,
baut daraus eine Seite und veröffentlicht sie auf GitHub Pages. Die Seite ist mit einem
Passwort verschlüsselt. Du rufst sie auf dem Handy per Link ab, am besten als Icon auf dem Home-Bildschirm.

Kosten: 0 €. Dein Rechner muss dafür nicht laufen.

## Was du brauchst
- Garmin-Connect-Konto (hast du)
- GitHub-Konto (kostenlos): https://github.com/signup
- Etwa 20 Minuten

## Schritt 1: Garmin-Key erstellen
1. Im Browser (nicht in der App) einloggen: https://connect.garmin.com/app/settings/personalApiToken
2. "Create Key", Bedingungen akzeptieren, Ablauf wählen (maximal 1 Jahr), "Create".
3. Key kopieren. Er wird nur einmal angezeigt. Speichere ihn kurz in einem Passwortmanager.

## Schritt 2: Repository anlegen
1. https://github.com/new
2. Name: `garmin-dashboard`, Sichtbarkeit: **Public** (nötig, weil GitHub Pages in privaten Repos
   erst mit bezahltem Konto geht). Keine Sorge: Im Repo liegt nur Code, deine Daten liegen nie darin.
3. "Create repository".
4. Auf der leeren Repo-Seite "uploading an existing file" klicken und **alle Dateien aus diesem Ordner
   hochladen**, inklusive des versteckten Ordners `.github`. Tipp: Den Ordner `.github` einzeln hineinziehen,
   falls er beim Auswählen nicht erscheint. Dann "Commit changes".

   Muss am Ende so aussehen:
   ```
   .github/workflows/update.yml
   .gitignore
   .staticrypt.json
   README.md
   build.py
   requirements.txt
   template.html
   ```

## Schritt 3: Zwei Secrets eintragen
Repo -> Settings -> Secrets and variables -> Actions -> "New repository secret"

| Name | Inhalt |
|---|---|
| `GARMIN_PERSONAL_API_KEY` | der Key aus Schritt 1 |
| `DASHBOARD_PASSWORD` | ein langes Passwort, mindestens 4 zufällige Wörter oder 16+ Zeichen |

Das Passwort muss lang sein: Die verschlüsselte Seite ist öffentlich abrufbar, und ein kurzes
Passwort könnte offline durchprobiert werden.

## Schritt 4: GitHub Pages einschalten
Repo -> Settings -> Pages -> Build and deployment -> Source: **GitHub Actions**.

## Schritt 5: Ersten Lauf starten
1. Reiter **Actions** -> links "Dashboard aktualisieren" -> "Run workflow".
2. Nach 1 bis 2 Minuten sollte alles grün sein.
3. Deine Adresse: `https://DEIN-GITHUB-NAME.github.io/garmin-dashboard/`

Ab jetzt aktualisiert sich die Seite alle 3 Stunden von selbst.

## Schritt 6: Aufs Handy
1. Adresse im Browser öffnen, Passwort eingeben, "Angemeldet bleiben" anhaken.
2. iPhone (Safari): Teilen -> "Zum Home-Bildschirm". Android (Chrome): Menü -> "Zum Startbildschirm hinzufügen".

## Vorschau ohne Garmin-Key (optional, am Rechner)
```
pip install -r requirements.txt
python build.py --demo
```
Dann `dist/index.html` im Browser öffnen.

## Wenn etwas nicht klappt
- **Lauf ist rot, "Key fehlt, abgelaufen"**: Neuen Key erstellen (Schritt 1) und das Secret ersetzen.
  Rot werden die Läufe auch, wenn der Key abläuft. GitHub schickt dir dann eine Mail.
- **Seite zeigt 404**: Schritt 4 vergessen, danach den Workflow noch einmal starten.
- **Updates stoppen nach ein paar Monaten**: Actions -> Workflow auswählen -> "Enable workflow".
  Der Keepalive-Schritt soll das verhindern, ist aber ein Sicherheitsnetz und keine Garantie.
- **Zahlen fehlen**: Die Uhr muss mit der Garmin-Connect-App synchronisiert haben.

## Was das Dashboard zeigt, und was nicht
Schlaf, HRV mit Normalbereich, Ruhepuls, Body Battery, Wochenstunden je Sportart, Laufkilometer,
letzte Läufe, VO2max.

**Training Readiness und Endurance Score** gibt die Personal API derzeit nicht heraus. Die
"Tagesform" im Dashboard ist deshalb eine eigene Schätzung (Formel steht unten auf der Seite) und
kann von Garmins Wert abweichen. Wenn Garmin die Endpunkte nachrüstet, lassen sie sich in `build.py`
ergänzen.
