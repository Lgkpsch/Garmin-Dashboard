#!/usr/bin/env python3
"""Holt deine Garmin-Daten über die Personal API und baut dist/index.html.

Aufruf:
    python build.py          # echte Daten (Key aus GARMIN_PERSONAL_API_KEY oder ~/.config/garmin/)
    python build.py --demo   # Beispieldaten, zum Anschauen ohne Key
"""
from __future__ import annotations

import argparse
import json
import random
import statistics
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Europe/Berlin")
ROOT = Path(__file__).parent
DAILY_DAYS = 56        # Tage mit Schlaf/HRV/Ruhepuls
ACTIVITY_DAYS = 112    # 16 Wochen Training
WEEKDAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]


def warn(msg: str) -> None:
    # Die Logs eines öffentlichen Repos sind öffentlich: hier nie Daten ausgeben.
    print(f"WARNUNG: {msg}", file=sys.stderr)


def num(x):
    try:
        return None if x is None else float(x)
    except (TypeError, ValueError):
        return None


def clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, x))


# --------------------------------------------------------------------------
# 1) Daten holen
# --------------------------------------------------------------------------
def fetch_live(today: date) -> dict:
    from gcpapi_sync import GarminClient
    from gcpapi_sync.exceptions import AuthenticationError, ConfigurationError

    start = today - timedelta(days=DAILY_DAYS - 1)
    act_start = today - timedelta(days=ACTIVITY_DAYS - 1)
    raw = {"sleep": [], "hrv": [], "daily": [], "activities": []}

    try:
        with GarminClient() as g:
            jobs = {
                "sleep": lambda: g.get_daily_sleep_summaries(start, today),
                "hrv": lambda: g.get_daily_hrv_summaries(start, today),
                "daily": lambda: g.get_daily_summaries(start, today),
                "activities": lambda: g.iter_activities(
                    page_size=40,
                    start_date=act_start.isoformat(),
                    end_date=today.isoformat(),
                ),
            }
            for key, job in jobs.items():
                try:
                    raw[key] = list(job())
                except (AuthenticationError, ConfigurationError):
                    raise
                except Exception as e:  # ein kaputter Endpunkt soll nicht alles stoppen
                    warn(f"{key}: {type(e).__name__}")
    except (AuthenticationError, ConfigurationError) as e:
        sys.exit(
            f"FEHLER: Garmin-Key fehlt, ist abgelaufen oder wurde gelöscht ({type(e).__name__}). "
            "Neuen Key in Garmin Connect erstellen und das GitHub-Secret aktualisieren."
        )
    return normalise(raw)


def normalise(raw: dict) -> dict:
    sleep, hrv, daily, acts = {}, {}, {}, []

    for s in raw["sleep"]:
        if not s.calendar_date or not s.sleep_time_seconds:
            continue
        overall = s.sleep_scores.overall if s.sleep_scores else None
        sleep[s.calendar_date.isoformat()] = dict(
            score=num(overall.value) if overall else None,
            total=num(s.sleep_time_seconds),
            deep=num(s.deep_sleep_seconds),
            rem=num(s.rem_sleep_seconds),
            light=num(s.light_sleep_seconds),
            awake=num(s.awake_sleep_seconds),
            hr=num(s.avg_heart_rate),
        )

    for h in raw["hrv"]:
        if not h.calendar_date:
            continue
        b = h.baseline
        hrv[h.calendar_date.isoformat()] = dict(
            last=num(h.last_night_avg),
            weekly=num(h.weekly_avg),
            low=num(b.balanced_low) if b else None,
            high=num(b.balanced_upper) if b else None,
            status=h.status,
        )

    for u in raw["daily"]:
        if not u.calendar_date:
            continue
        hr, st, bb = u.heart_rate, u.stress, u.body_battery
        daily[u.calendar_date.isoformat()] = dict(
            rhr=num(hr.resting_value) if hr else None,
            stress=num(st.avg_level) if st else None,
            bb_max=num(bb.max_value) if bb else None,
            bb_min=num(bb.min_value) if bb else None,
        )

    for a in raw["activities"]:
        if not a.start_time_local:
            continue
        acts.append(
            dict(
                id=a.activity_id,
                name=a.activity_name or "",
                day=a.start_time_local.date().isoformat(),
                type=(a.activity_type.type_key if a.activity_type else "") or "",
                dist=num(a.distance),
                dur=num(a.duration),
                hr=num(a.average_hr),
                ascent=num(a.elevation_gain),
                vo2=num(a.vo2_max_value),
            )
        )
    return dict(sleep=sleep, hrv=hrv, daily=daily, acts=acts)


def demo_data(today: date) -> dict:
    rnd = random.Random(42)
    sleep, hrv, daily, acts = {}, {}, {}, []
    for i in range(DAILY_DAYS):
        d = (today - timedelta(days=DAILY_DAYS - 1 - i)).isoformat()
        total = rnd.gauss(7.2, 0.7) * 3600
        sleep[d] = dict(
            score=clamp(rnd.gauss(78, 8)), total=total, deep=total * 0.17,
            rem=total * 0.22, light=total * 0.52, awake=total * 0.09, hr=rnd.gauss(46, 2),
        )
        hrv[d] = dict(last=rnd.gauss(68, 7), weekly=68, low=58, high=78, status="BALANCED")
        daily[d] = dict(rhr=rnd.gauss(46, 1.8), stress=rnd.gauss(27, 6),
                        bb_max=clamp(rnd.gauss(82, 10)), bb_min=clamp(rnd.gauss(18, 8)))
    kinds = ["running", "running", "cycling", "lap_swimming", "strength_training", "running"]
    for i in range(ACTIVITY_DAYS):
        if rnd.random() < 0.7:
            k = rnd.choice(kinds)
            dist = {"running": rnd.uniform(6, 22) * 1000, "cycling": rnd.uniform(25, 90) * 1000,
                    "lap_swimming": rnd.uniform(1.2, 3) * 1000}.get(k, 0)
            speed = {"running": 3.0, "cycling": 7.5, "lap_swimming": 0.9}.get(k, 1)
            acts.append(dict(
                id=i, name=f"{k} {i}", day=(today - timedelta(days=i)).isoformat(), type=k,
                dist=dist, dur=(dist / speed) if dist else rnd.uniform(2400, 4200),
                hr=rnd.gauss(148, 8), ascent=rnd.uniform(10, 300),
                vo2=round(rnd.gauss(55, 0.6)) if k == "running" and rnd.random() < 0.5 else None,
            ))
    return dict(sleep=sleep, hrv=hrv, daily=daily, acts=acts)


# --------------------------------------------------------------------------
# 2) Auswerten
# --------------------------------------------------------------------------
def sport_of(key: str) -> str:
    k = key.lower()
    if "run" in k:
        return "run"
    if "swim" in k:
        return "swim"
    if any(t in k for t in ("cycl", "bik", "ride")):
        return "bike"
    return "other"


def baseline(series, i, window=28):
    prev = [v for v in series[max(0, i - window):i] if v is not None]
    return prev if len(prev) >= 7 else None


def z_score(series, i, higher_better, floor):
    x = series[i]
    prev = baseline(series, i)
    if x is None or prev is None:
        return None, None
    m = statistics.fmean(prev)
    sd = max(statistics.pstdev(prev), floor)
    z = (x - m) / sd
    return clamp(70 + 15 * (z if higher_better else -z)), m


def build_payload(data: dict, today: date) -> dict:
    dates = [today - timedelta(days=DAILY_DAYS - 1 - i) for i in range(DAILY_DAYS)]
    iso = [d.isoformat() for d in dates]

    sl = [data["sleep"].get(d) for d in iso]
    hv = [data["hrv"].get(d) for d in iso]
    dy = [data["daily"].get(d) for d in iso]

    hrv_s = [x["last"] if x else None for x in hv]
    rhr_s = [x["rhr"] if x else None for x in dy]
    sleep_s = [x["score"] if x else None for x in sl]
    bb_s = [x["bb_max"] if x else None for x in dy]

    minutes_per_day = {}
    for a in data["acts"]:
        minutes_per_day[a["day"]] = minutes_per_day.get(a["day"], 0) + (a["dur"] or 0) / 60

    def readiness(i):
        parts = {}
        hs, _ = z_score(hrv_s, i, True, 3.0)
        rs, _ = z_score(rhr_s, i, False, 1.5)
        if hs is not None: parts["hrv"] = (hs, 0.30)
        if rs is not None: parts["rhr"] = (rs, 0.20)
        if sleep_s[i] is not None: parts["sleep"] = (sleep_s[i], 0.30)
        if bb_s[i] is not None: parts["bb"] = (bb_s[i], 0.20)
        if len(parts) < 2:
            return None
        wsum = sum(w for _, w in parts.values())
        score = sum(s * w for s, w in parts.values()) / wsum
        acute = sum(minutes_per_day.get(iso[j], 0) for j in range(max(0, i - 2), i + 1)) / 3
        chronic_days = [minutes_per_day.get(iso[j], 0) for j in range(max(0, i - 28), i)]
        chronic = statistics.fmean(chronic_days) if chronic_days else 0
        if chronic >= 10:
            score -= clamp((acute / chronic - 1.3) * 20, 0, 15)
        return round(clamp(score))

    days = []
    for i, d in enumerate(iso):
        s, h, y = sl[i], hv[i], dy[i]
        days.append(dict(
            date=d,
            sleep_score=s["score"] if s else None,
            sleep_h=round(s["total"] / 3600, 2) if s else None,
            deep=round(s["deep"] / 60) if s and s["deep"] is not None else None,
            rem=round(s["rem"] / 60) if s and s["rem"] is not None else None,
            light=round(s["light"] / 60) if s and s["light"] is not None else None,
            awake=round(s["awake"] / 60) if s and s["awake"] is not None else None,
            hrv=h["last"] if h else None,
            hrv_low=h["low"] if h else None,
            hrv_high=h["high"] if h else None,
            hrv_status=h["status"] if h else None,
            rhr=y["rhr"] if y else None,
            stress=y["stress"] if y else None,
            bb_max=y["bb_max"] if y else None,
            bb_min=y["bb_min"] if y else None,
            readiness=readiness(i),
        ))

    # Wochenwerte (Montag bis Sonntag), 16 Wochen
    this_monday = today - timedelta(days=today.weekday())
    weeks = []
    for w in range(15, -1, -1):
        mon = this_monday - timedelta(weeks=w)
        sun = mon + timedelta(days=6)
        wk = dict(start=mon.isoformat(), run_km=0.0, longest_run_km=0.0,
                  h_run=0.0, h_bike=0.0, h_swim=0.0, h_other=0.0, sessions=0)
        for a in data["acts"]:
            if not (mon.isoformat() <= a["day"] <= sun.isoformat()):
                continue
            sp = sport_of(a["type"])
            hours = (a["dur"] or 0) / 3600
            wk[f"h_{sp}"] += hours
            wk["sessions"] += 1
            if sp == "run":
                km = (a["dist"] or 0) / 1000
                wk["run_km"] += km
                wk["longest_run_km"] = max(wk["longest_run_km"], km)
        for k in ("run_km", "longest_run_km", "h_run", "h_bike", "h_swim", "h_other"):
            wk[k] = round(wk[k], 2)
        weeks.append(wk)

    runs = sorted((a for a in data["acts"] if sport_of(a["type"]) == "run"),
                  key=lambda a: (a["day"], a["id"] or 0), reverse=True)[:12]
    run_list = []
    for a in runs:
        km = (a["dist"] or 0) / 1000
        mins = (a["dur"] or 0) / 60
        run_list.append(dict(
            day=a["day"], name=a["name"], km=round(km, 2), min=round(mins),
            pace=round(mins / km, 3) if km > 0.1 else None,
            hr=round(a["hr"]) if a["hr"] else None,
            ascent=round(a["ascent"]) if a["ascent"] is not None else None,
        ))

    vo2 = {}
    for a in sorted(data["acts"], key=lambda a: a["day"]):
        if a["vo2"]:
            vo2[a["day"]] = a["vo2"]
    vo2_list = [dict(day=k, value=v) for k, v in list(vo2.items())[-20:]]

    # Zusammenfassung für die erste Ansicht
    idx = next((i for i in range(len(days) - 1, -1, -1) if days[i]["readiness"] is not None), len(days) - 1)
    comps = []

    def comp(label, series, i, unit, higher_better, floor, direct=False, digits=0):
        v = series[i]
        if v is None:
            return
        if direct:
            score, mean = v, None
            prev = baseline(series, i)
            mean = statistics.fmean(prev) if prev else None
        else:
            score, mean = z_score(series, i, higher_better, floor)
        comps.append(dict(label=label, value=round(v, digits) if digits else round(v), unit=unit,
                          mean=round(mean, digits) if mean is not None and digits else (round(mean) if mean is not None else None),
                          score=round(score) if score is not None else None, higher_better=higher_better))

    comp("Herzratenvariabilität", hrv_s, idx, "ms", True, 3.0)
    comp("Ruhepuls", rhr_s, idx, "bpm", False, 1.5)
    comp("Schlaf", sleep_s, idx, "von 100", True, 1, direct=True)
    comp("Body Battery", bb_s, idx, "max.", True, 1, direct=True)

    now = datetime.now(TZ)
    return dict(
        stand=f"{WEEKDAYS[now.weekday()]}, {now:%d.%m.} um {now:%H:%M} Uhr",
        latest=days[idx]["date"],
        readiness=days[idx]["readiness"],
        comps=comps,
        days=days,
        weeks=weeks,
        runs=run_list,
        vo2=vo2_list,
    )


# --------------------------------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true", help="Beispieldaten statt Garmin-Abruf")
    args = ap.parse_args()

    today = datetime.now(TZ).date()
    data = demo_data(today) if args.demo else fetch_live(today)
    print(f"Schlaf: {len(data['sleep'])} Tage, HRV: {len(data['hrv'])}, "
          f"Tageswerte: {len(data['daily'])}, Aktivitäten: {len(data['acts'])}")
    if not any((data["sleep"], data["hrv"], data["daily"], data["acts"])):
        sys.exit("FEHLER: Garmin hat keine Daten geliefert. Seite wird nicht überschrieben.")

    payload = build_payload(data, today)
    html = (ROOT / "template.html").read_text(encoding="utf-8")
    blob = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    out = ROOT / "dist"
    out.mkdir(exist_ok=True)
    (out / "index.html").write_text(html.replace("__DATA__", blob), encoding="utf-8")
    print("dist/index.html geschrieben")


if __name__ == "__main__":
    main()
